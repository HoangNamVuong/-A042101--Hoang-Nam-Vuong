package com.codegym.sessionandcookie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SessioncookieApplicationTests {

    @Test
    void contextLoads() {
    }

}
