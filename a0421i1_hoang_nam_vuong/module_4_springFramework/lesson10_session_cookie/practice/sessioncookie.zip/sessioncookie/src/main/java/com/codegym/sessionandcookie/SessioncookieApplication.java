package com.codegym.sessionandcookie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SessioncookieApplication {

    public static void main(String[] args) {
        SpringApplication.run(SessioncookieApplication.class, args);
    }

}
